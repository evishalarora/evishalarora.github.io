const dom = exports;

dom.document = null;

dom._create_row = function() {
	var document = this.document;
	var tr = document.createElement("tr");
	for(var i = 0; i < arguments.length; i++) {
		var td = document.createElement("td");
		if(i % 2 == 0) {
			var b = document.createElement("b");
			b.innerText = arguments[i];
			td.appendChild(b);
		} else {
			td.innerText = arguments[i];
		}
		tr.appendChild(td);
	}
	return tr;
}

dom._concat_roles = function(roles) {
	var r = new Array;
	for(var i = 0; i < roles.length; i++) {
		r[i] = roles[i].name.value;
	}
	return r.join(", ");
}

dom.print = function(subject, qcStatement) {
	var table = this.document.createElement("table");
	table.appendChild(this._create_row("Org Id", subject.id));
	table.appendChild(this._create_row("Organization Name", subject.organizationName));
	table.appendChild(this._create_row("Jurisdiction", subject.jurisdictionOfIncorporation));
	table.appendChild(this._create_row("Business Category", subject.businessCategory));
	table.appendChild(this._create_row("Serial Number", subject.serialNumber));
	table.appendChild(this._create_row("Authority ID", qcStatement.authorityId.value));
	table.appendChild(this._create_row("Authority Name", qcStatement.authorityName.value));
	table.appendChild(this._create_row("PSD2 Roles", this._concat_roles(qcStatement.roles)));
	return table;
}